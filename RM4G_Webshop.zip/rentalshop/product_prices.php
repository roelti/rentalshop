<?php // FUNCTIONS REGARDING PRICES AND FEES OF PRODUCTS

    // ------------- Main Product Price Functions ------------- \\

    # Apply staffel on the prices of the products
    function apply_staffel(){
        $staffels = array();
        $pf = new WC_Product_Factory();

        # Get token and dates
        $fromDate = strtotime(get_option('plugin-startdate'));
        $endDate = strtotime(get_option('plugin-enddate'));
        $totaldays = abs($endDate - $fromDate);
        $totaldays = ceil($totaldays / (3600*24));
        $token = get_option('plugin-token');

        # Fill staffel-array with data from the cart
        $items = WC()->cart->get_cart();
        foreach ($items as $item => $values){
            $_product = $values['data']->post;
            $product = $pf->get_product($_product->ID);
            $staffelgroup = get_staffelgroup($token, $product->get_sku());
            if ($staffelgroup == null)
                $staffels[$product->get_sku()] = '1.0';
            else
                $staffels[$product->get_sku()] = get_staffel($token, $totaldays, $staffelgroup);
        }

        # Calculate the additional fee and add it to the cart
        $fee = calculate_fee($staffels);
        WC()->cart->add_fee('Staffel', $fee, true, 'standard');
    }

    # Get staffel from Rentman
    function get_staffel($token, $totaldays, $staffelgroup){
        $url = receive_endpoint();

        # Setup Request to send JSON
        $message = json_encode(setup_staffel_request($token, $totaldays, $staffelgroup), JSON_PRETTY_PRINT);

        # Send Request & Receive Response
        $received = do_request($url, $message);

        $parsed = json_decode($received, true);
        $stafObject = current($parsed['response']['items']['Staffel']);

        return $stafObject['data'][2];
    }

    # Get staffelgroup of products in cart
    function get_staffelgroup($token, $product_id){
        $url = receive_endpoint();

        # Setup Request to send JSON
        $message = json_encode(setup_staffelgroup_request($token, $product_id), JSON_PRETTY_PRINT);

        # Send Request & Receive Response
        $received = do_request($url, $message);

        $parsed = json_decode($received, true);
        $stafObject = current($parsed['response']['items']['Materiaal']);

        # If product is only for sale
        if ($stafObject['data'][3] == false)
            return null;

        return $stafObject['data'][2];
    }

    # Get staffel array for project export
    function get_staffels($order_id){
        global $wpdb;
        $order = new WC_Order($order_id);
        $staffels = array();

        # Get token and dates
        $fromDate = strtotime(get_option('plugin-startdate'));
        $endDate = strtotime(get_option('plugin-enddate'));
        $totaldays = abs($endDate - $fromDate);
        $totaldays = ceil($totaldays / (3600*24));
        $token = get_option('plugin-token');

        # Get staffel data for all items
        foreach($order->get_items() as $key => $lineItem){
            $name = $lineItem['name'];
            $product_id = $wpdb->get_var( "SELECT ID FROM $wpdb->posts WHERE post_title = '" . $name . "'" );
            $product = wc_get_product($product_id);
            $staffelgroup = get_staffelgroup($token, $product->get_sku());
            if ($staffelgroup == null)
                $staffels[$product->get_sku()] = '1,0';
            else
                $staffels[$product->get_sku()] = get_staffel($token, $totaldays, $staffelgroup);

        }
        return $staffels;
    }

    # Calculate the total fee of the shopping cart
    function calculate_fee($staffels){
        $pf = new WC_Product_Factory();
        $totalprice = 0;
        $items = WC()->cart->get_cart();
        foreach ($items as $item => $values){
            $_product = $values['data']->post;
            $amount = $items[$item]["quantity"];
            $product = $pf->get_product($_product->ID);
            $staffel = $staffels[$product->get_sku()];
            $carttotals = $product->get_price() * $amount;
            $staffelprice = $carttotals * $staffel;
            $totalprice += $staffelprice - $carttotals;
        }
        return $totalprice;
    }

    // ------------- API Request ------------- \\

    # Returns API request ready to be encoded in Json
    # For getting staffel by staffelgroup
    function setup_staffel_request($token, $totaldays, $staffelgroup){
        $object_data = array(
            "requestType" => "query",
            "client" => array(
                "language" => "1",
                "type" => "webshopplugin",
                "version" => "2"
            ),
            "account" => get_option('plugin-account'),
            "token" => $token,
            "itemType" => "Staffel",
            "columns" => array(
                "Staffel" => array(
                    "id",
                    "displayname",
                    "staffel",
                    "staffelgroep",
                    "van",
                    "tot"
                )
            ),
            "query" => array(
                "conditions" => array(
                    array(
                        "key" => "staffelgroep",
                        "value" => $staffelgroup
                    ),
                    array(
                        "key" => "van",
                        "value" => $totaldays,
                        "comparator" => "<="
                    ),
                    array(
                        "key" => "tot",
                        "value" => $totaldays,
                        "comparator" => ">="
                    )
                ))
        );
        return $object_data;
    }

    # Returns API request ready to be encoded in Json
    # For getting staffelgroups
    function setup_staffelgroup_request($token, $product_id){
        $object_data = array(
            "requestType" => "query",
            "client" => array(
                "language" => "1",
                "type" => "webshopplugin",
                "version" => "2"
            ),
            "account" => get_option('plugin-account'),
            "token" => $token,
            "itemType" => "Materiaal",
            "columns" => array(
                "Materiaal" => array(
                    "naam",
                    "verhuurprijs",
                    "staffelgroep",
                    "verhuur"
                )
            ),
            "query" => array("id" => $product_id)
        );
        return $object_data;
    }
?>